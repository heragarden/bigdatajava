package jdbc;

import javax.swing.JOptionPane;

public class 검색처리 {

	public static void main(String[] args) throws Exception {
		DB처리 db = new DB처리();
		String id = JOptionPane.showInputDialog("ID입력: ");
		//select * from member where id = ?
		String[] mem = db.select(id);
		for (String s : mem) {
			System.out.println(s);
		}
		
		
		
		
		
		
		
		
	}

}
