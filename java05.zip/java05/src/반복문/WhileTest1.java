package 반복문;

public class WhileTest1 {

	public static void main(String[] args) {
		//반복할 때 사용하는 문법-while, for
//		while(true) { //무한루프
		int x = 100;
		int y = 200;
		
		while(x < y) {
			System.out.println("환영합니다.");
			x = x + 10;
		}
	}

}
