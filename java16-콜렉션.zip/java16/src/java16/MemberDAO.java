package java16;

import java.util.ArrayList;

public class MemberDAO {
	public ArrayList selectAll() {
		ArrayList list = new ArrayList();
		//dto를 3개를 만들어서  list로 묶으세요.
		//그 리스트를 리턴.
		return list;
	}
}
