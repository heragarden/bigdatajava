package java16;

public class MemberDAOUser {

	public static void main(String[] args) {
		//멤버리스트를 리턴받아
		//전체 출력
	}
}
