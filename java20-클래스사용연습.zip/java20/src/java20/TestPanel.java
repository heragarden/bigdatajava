package java20;

import java.awt.Panel;

public class TestPanel extends Panel {

	public TestPanel(String p) {
		
	}
}
