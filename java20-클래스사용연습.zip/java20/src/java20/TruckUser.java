package java20;

public class TruckUser {

	public static void main(String[] args) {
		Truck t = new Truck();
	}

}
