package java20;

public class Test {
	static String name;

	public static void main(String[] args) {
		name = "hello";
		Test2 t2 = new Test2();
//		t2.call(name);
		
	}

}
