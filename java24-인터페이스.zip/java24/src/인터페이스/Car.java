package 인터페이스;

public interface Car {
	void start();
	void speedUp();
	void speedDown();
}
