package 인터페이스;

import java.util.ArrayList;

public class Test {

	public static void main(String[] args) {
		ArrayList list = new ArrayList();
		list.add(22.22);
		double d = (double)list.get(0);
	}
}
