package 인터페이스;

public class AppleCar {

	public void run() {
		System.out.println("차가 출발하다.");
	} 
	
	public void 속도를Up() {
		System.out.println("속도를 Up");
	}
	
	public void 속도를Down() {
		System.out.println("속도를 Down");
	}
		

}
