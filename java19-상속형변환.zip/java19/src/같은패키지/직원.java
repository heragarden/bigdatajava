package 같은패키지;

public class 직원 {
	public String name; 
	protected int salary; //월급
	int age;
	private String ssn; //주민번호
	
}
