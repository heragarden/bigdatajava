package 배열;

public class 배열연습4 {

	public static void main(String[] args) {
		int[] num1 = {1,2,3};
		int[] num2 = num1;
		System.out.println(num1);
		}
}
