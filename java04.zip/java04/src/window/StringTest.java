package window;

public class StringTest {

	public static void main(String[] args) {
		String s1 = "+";
		
		if("-".equals(s1)) {
			System.out.println("동일합니다.");
		}else {
			System.out.println("동일하지 않습니다.");
		}
	}

}
