package control;

import java.util.Random;

public class 랜덤테스트 {

	public static void main(String[] args) {
		//아무값이나 만들어주는 class: Random
		Random random = new Random();
		System.out.println(random.nextInt(100));
	}
}





