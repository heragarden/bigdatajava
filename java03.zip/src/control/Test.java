package control;

public class Test {

	public static void main(String[] args) {
		int num = 0; //시작값
		while(num<10) { //조건
			System.out.println("실행내용..");
			num = num + 1; //증감
		}
	}

}
