package java08;

public class 아스키코드문자넣기 {

	public static void main(String[] args) {
		char[] list = {97, 98};
		for (char c : list) {
			System.out.println(c);
		}
	}

}
