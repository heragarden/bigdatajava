package java09;

public class 다이나믹배열 {

	public static void main(String[] args) {
		int[][] num = new int[2][];
		num[0][2] = 100;
		//System.out.println(num[0][2]);
		
		
	}

}
