package java17;

public class 중학생 extends 학생{
	int english; //영어듣기평가 시간
	
	@Override
	public void 공부하다() {
		System.out.println("영어 공부하다.");
	}
	public void buauty() {
		System.out.println("화장을 시작하다.");
	}
	
}
