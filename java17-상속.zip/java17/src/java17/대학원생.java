package java17;

public class 대학원생 extends 학생 {

}
