package java17;

public class 고등학생 extends 학생{
	int studyTime;

	@Override
	public void 공부하다() {
		System.out.println("입시공부하다.");
	}
	
	
	public void plan() {
		System.out.println("대입을 준비하다.");
	}
}






