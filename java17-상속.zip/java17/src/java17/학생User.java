package java17;

public class 학생User {

	public static void main(String[] args) {
		초등학생 초등 = new 초등학생();
		중학생 중등 = new 중학생();
		고등학생 고등 = new 고등학생();
		초등.ins();
		중등.buauty();
		고등.plan();
		고등.name = "김아무개";
		고등.공부하다();
		중등.공부하다();
		초등.공부하다();
		
	}

}
