package java17;

import javax.swing.JPanel;

public class MyPanel2 {
	public MyPanel2() {
		JPanel p = new JPanel();
	}

}
