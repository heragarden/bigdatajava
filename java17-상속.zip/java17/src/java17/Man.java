package java17;

public class Man extends Person{
	//정적속성
	int eye;
	
	//동적속성
	public void army() {
		System.out.println("군대가다.");
	}
	
}
