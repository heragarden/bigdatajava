package 인터페이스;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class CollectionTest {

	public static void main(String[] args) {
		List list = new ArrayList();
		Set set = new HashSet();
	}
}




