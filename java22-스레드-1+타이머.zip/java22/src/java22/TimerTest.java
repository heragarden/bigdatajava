package java22;

import java.util.TimerTask;

public class TimerTest extends TimerTask {
	@Override
	public void run() {
		System.out.println("게임이 종료되었습니다.");
	}

}
