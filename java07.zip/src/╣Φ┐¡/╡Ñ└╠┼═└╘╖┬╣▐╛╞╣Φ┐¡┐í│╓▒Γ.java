package 배열;

import java.util.Scanner;

public class 데이터입력받아배열에넣기 {

	public static void main(String[] args) {
		Scanner	sc = new Scanner(System.in);
		
		System.out.println("값 3개를 넣으세요.");
		int num1 = sc.nextInt();
		int num2 = sc.nextInt();
		int num3 = sc.nextInt();
		
		System.out.println(num1);
		System.out.println(num2);
		System.out.println(num3);
		
		
		
		
		
		
		
		
		
	}

}
